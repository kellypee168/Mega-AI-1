const $=id=>document.getElementById(id);

const messages=$("messages");
const welcome=$("welcome");

let chats=JSON.parse(localStorage.getItem("megaChats")||"[]");

let current=[];
let chatId=null;
let image=null;

function save(){

if(!current.length)return;

const title=(current.find(x=>x.role==="user")?.text||"New chat").slice(0,36);

const i=chats.findIndex(x=>x.id===chatId);

const c={
id:chatId||Date.now(),
title,
messages:current
};

if(i<0){
chatId=c.id;
chats.push(c);
}else{
chats[i]=c;
}

localStorage.setItem("megaChats",JSON.stringify(chats));

history();

}

function history(){

$("historyList").innerHTML="";

chats.slice().reverse().forEach(c=>{

let d=document.createElement("div");

d.className="history-item";

d.textContent=c.title;

d.onclick=()=>{
chatId=c.id;
current=c.messages.slice();
render();
};

$("historyList").append(d);

});

}

function render(){

messages.innerHTML="";

welcome.hidden=current.length>0;

current.forEach(m=>{

let row=document.createElement("div");

row.className="message "+m.role;

let a=document.createElement("div");

a.className="avatar";

a.textContent=m.role==="user"?"Y":"M";

let b=document.createElement("div");

b.className="bubble";

b.textContent=m.text;

if(m.image){

let im=document.createElement("img");

im.src=m.image;

im.alt="Attached image";

b.append(im);

}

row.append(a,b);

messages.append(row);

});

$("chatArea").scrollTop=$("chatArea").scrollHeight;

history();

}

function add(role,text,img){

current.push({
role,
text,
image:img||null
});

render();

save();

}

$("imageInput").onchange=()=>{

let f=$("imageInput").files[0];

if(!f)return;

if(!f.type.startsWith("image/")||f.size>5*1024*1024){

alert("Choose an image smaller than 5 MB.");

return;

}

let r=new FileReader();

r.onload=()=>{

image={
data:r.result,
mimeType:f.type
};

$("imagePreview").hidden=false;

$("imagePreview").innerHTML=`
<img src="${r.result}">
${f.name}
<button type="button" id="removeImage">Remove</button>
`;

$("removeImage").onclick=()=>{

image=null;

$("imagePreview").hidden=true;

$("imageInput").value="";

};

};

r.readAsDataURL(f);

};

$("chatForm").onsubmit=async e=>{

e.preventDefault();

let text=$("messageInput").value.trim();

if(!text&&!image)return;

let pic=image;

add("user",text||"Please describe this image.",pic?.data);

$("messageInput").value="";

$("messageInput").style.height="auto";

image=null;

$("imagePreview").hidden=true;

$("imageInput").value="";

let t=document.createElement("div");

t.className="message";

t.id="typing";

t.innerHTML='<div class="avatar">M</div><div class="bubble typing">MEGA is thinking…</div>';

messages.append(t);

$("sendButton").disabled=true;

try{

let history=current.slice(0,-1).map(m=>({

role:m.role==="assistant"?"model":"user",

text:m.text

}));

let res=await fetch("/api/chat",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

message:text||"Please describe this image.",

history,

image:pic?{
data:pic.data.split(",")[1],
mimeType:pic.mimeType
}:null

})

});

let data=await res.json();

if(!res.ok)throw Error(data.error||"Request failed");

$("typing")?.remove();

add("assistant",data.reply);

}catch(err){

$("typing")?.remove();

add("assistant","I couldn't connect: "+err.message+" Check the server and Gemini API key.");

}finally{

$("sendButton").disabled=false;

}

};

$("messageInput").oninput=e=>{

e.target.style.height="auto";

e.target.style.height=Math.min(e.target.scrollHeight,140)+"px";

};

$("messageInput").onkeydown=e=>{

if(e.key==="Enter"&&!e.shiftKey){

e.preventDefault();

$("chatForm").requestSubmit();

}

};

$("newChat").onclick=()=>{

current=[];

chatId=null;

render();

$("sidebar").classList.remove("open");

};

$("clearChat").onclick=()=>{

current=[];

chatId=null;

render();

};

$("menuButton").onclick=()=>$("sidebar").classList.toggle("open");

document.querySelectorAll("[data-prompt]").forEach(b=>{

b.onclick=()=>{

$("messageInput").value=b.dataset.prompt;

$("chatForm").requestSubmit();

};

});

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;

$("voiceButton").onclick=()=>{

if(!SR){

alert("Voice input is not supported in this browser.");

return;

}

let r=new SR();

r.lang="en-US";

r.onresult=e=>$("messageInput").value+=e.results[0][0].transcript;

r.start();

};

history();

render();