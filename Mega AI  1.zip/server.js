require("dotenv").config();

const express=require("express");
const path=require("path");
const helmet=require("helmet");

const {GoogleGenAI}=require("@google/genai");

const app=express();

const PORT=process.env.PORT||3000;

const MODEL=process.env.GEMINI_MODEL||"gemini-2.5-flash";

app.use(helmet({contentSecurityPolicy:false}));

app.use(express.json({limit:"8mb"}));

app.use(express.static(path.join(__dirname,"public")));

const ai=process.env.GEMINI_API_KEY
?new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY})
:null;

app.post("/api/chat",async(req,res)=>{

try{

if(!ai){

return res.status(500).json({
error:"GEMINI_API_KEY is missing. Add it to .env and restart."
});

}

const {message,history=[],image}=req.body||{};

if(typeof message!=="string"||!message.trim()){

return res.status(400).json({
error:"Enter a message."
});

}

const contents=[];

for(const m of history.slice(-20)){

if(m&&["user","model"].includes(m.role)&&typeof m.text==="string"){

contents.push({
role:m.role,
parts:[{text:m.text}]
});

}

}

const parts=[{text:message.trim()}];

if(image?.data&&image?.mimeType&&/^image\/(png|jpeg|webp|gif)$/.test(image.mimeType)){

parts.push({

inlineData:{
data:image.data,
mimeType:image.mimeType
}

});

}

contents.push({
role:"user",
parts
});

const result=await ai.models.generateContent({

model:MODEL,

contents,

config:{

systemInstruction:"You are MEGA AI, a helpful, accurate and friendly assistant. Explain clearly and admit when unsure."

}

});

res.json({

reply:result.text||"I could not generate a response. Please try again."

});

}catch(e){

console.error(e);

res.status(500).json({

error:"Gemini request failed. Check your API key, internet connection and model access."

});

}

});

app.get("/api/health",(_req,res)=>{

res.json({

ok:true,

model:MODEL,

configured:!!ai

});

});

app.listen(PORT,()=>{

console.log(`MEGA AI running at http://localhost:${PORT}`);

});