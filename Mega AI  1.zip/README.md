# MEGA AI — HTML5 Website

## Files

- public/index.html — HTML5 page
- public/style.css — Website design
- public/app.js — Chat functionality
- server.js — Gemini API backend
- .env.example — Environment variable template

## Run locally

1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run npm install.
4. Copy .env.example to a file named .env.
5. Enter your Gemini API key in .env.
6. Run npm start.
7. Open http://localhost:3000 in Chrome.

## Deploy online

Deploy as a Node.js application.

Build command:
npm install

Start command:
npm start

Add these environment variables:

GEMINI_API_KEY
GEMINI_MODEL
PORT

## Security

Keep your API key in .env.

Never put your API key in browser JavaScript or HTML.